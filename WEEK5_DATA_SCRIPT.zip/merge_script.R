setwd("C:\\06. FASHIONLOG")

library(foreign)
(x1 <- read.dta("x1_12.dta"))
(x2 <- read.dta("x2_12.dta"))

# merge two data frames by (left-join)
(total <- merge(x1,x2,by="id"))

# merge (full-join)
(x2e <- read.dta("x2e_12.dta"))
leftjoin <- merge(x1,x2e,by="id"); leftjoin
fulljoin <- merge(x1,x2e,by="id", all.y=T); fulljoin

# Linking senders to receivers
sr <- read.dta("sr.dta"); sr
summary(sr)
table(sr$receiver,sr$sender)

# Zip codes of senders and receivers
zip_sr <- read.dta("zip.dta"); zip_sr

# zip sender
sr_szip <- merge(sr,zip_sr,by.x="sender",by.y="id",all.x=T,all.y=F);
head(sr_szip);tail(sr_szip)

# rename variables: zip sender
# install.packages("reshape")
library(reshape)
sr_szip <- rename(sr_szip, c(pc4="pc4s"))

# rename variables: zip sender
sr_srzip <- merge(sr_szip,zip_sr,by.x="receiver",by.y="id",all.x=T,all.y=F);
sr_srzip <- rename(sr_srzip, c(pc4="pc4r"))
head(sr_srzip);tail(sr_srzip)

# Order cases and variables
col_order <- c("sender","pc4s","receiver","pc4r")
attach(sr_srzip)
sr_srzip <- sr_srzip[order(sender,receiver),col_order]
sr_srzip
detach(sr_srzip)

## Assignment

## -1- The coordinates of the postal codes (1111 to 9999), are in **zipcoor.dta**. Read the data.  

## -2- Merge the coordinates to the postal codes of the receiver and the sender.  

## -3- Compute the straight line distances between the senders and receivers. Add the variable containing this information to the data frame.  


